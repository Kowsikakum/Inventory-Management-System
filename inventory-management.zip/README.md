# Inventory Management System (Java - Spring Boot)

This is a simple Inventory Management System built with Spring Boot, Spring Data JPA, Thymeleaf and H2 database.
Run with: `mvn spring-boot:run` and open http://localhost:8080

Features:
- Add products
- List products
- Delete products
- Low-stock indicator
